#!/usr/bin/python
# -*- coding: utf-8 -*-

from pythymiodw import *

def print_temp(t_celcius):
    """ calculate t_fahrenheit and print both
    """
    pass

def forward(speed, duration):
    """ move both wheels for that duration, and stop
    """
    pass

robot = ThymioReal() # create an object

############### Start writing your code here ################ 

# Prompt user to enter speed and duration of movement

# Move according to the specified speed and duration

# Read temperature in celcius from the sensor and print it

########################## end ############################## 

robot.quit() # disconnect the communication

